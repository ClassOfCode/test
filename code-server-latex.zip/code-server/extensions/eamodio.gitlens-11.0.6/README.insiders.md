> **This is the insiders version of GitLens for early feedback and testing. It works best with [VS Code Insiders](https://code.visualstudio.com/insiders).**
