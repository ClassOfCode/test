'use strict';

const PREFIX = 'ipAddress.';

module.exports = {
  INSERT_IP_ADDRESS   : PREFIX + 'insertIPAddress',
  SHOW_NEXT_IP_ADDRESS: PREFIX + 'showNextIPAddress'
};
