# Sponsors

&#x1f496; To my incredible sponsors &mdash; thank you so much for your contributions. I am truly humbled by your generosity and support. If you'd like to join in sponsoring GitLens, please [click here](https://gitlens.amod.io/#sponsor).

## Corporate Sponsors

<p align="center" style="margin: 1em 10%">
  <a title="Try CodeStream &mdash; Pull Requests and Code Reviews in your IDE" href="https://sponsorlink.codestream.com/?utm_source=vscmarket&utm_medium=banner&utm_campaign=gitlens"><img src="https://alt-images.codestream.com/codestream_logo_gitlens_vscmarket.png" alt="CodeStream Logo &mdash; Pull Requests and Code Reviews in your IDE"/></a>

<p align="center" style="margin: 1em 10%">
  <a title="Visit Embark Studios" href="https://embark-studios.com"><img src="https://raw.githubusercontent.com/eamodio/vscode-gitlens/main/images/docs/sponsors/embark-studios_dark.png" alt="Embark Studios Logo"/></a>
</p>

<p align="center" style="margin: 1em 10%">
  <a title="Visit Crésus" href="https://cresus.ch"><img src="https://raw.githubusercontent.com/eamodio/vscode-gitlens/main/images/docs/sponsors/cresus.png" alt="Crésus Logo"/></a>
</p>

## User Sponsors

- Borek Bernard
- Jack
- Ken Howard
- Michael Duffy
- Michael Scott-Nelson
- MrG0lden
- Sergey Cheperis
- Xananax
- Andreas Fertsch-Röver
- Bill
- Brandon Burroughs
- Brent Schmidt
- Diego La Manno
- Eugen Grue
- Georg Hartmann
- Guido Kessels
- J Burnett
- JehongAhn
- Jon G
- Jordan Oroshiba
- Karl
- Michael Melanson
- Niklas Lochschmidt
- Pavel Khlopin
- Pelle Wessman
- Raphael Schweikert
- sombriks
- Stephen Kelley
- Steven Hepting
- Sunny Gupta
- Vance Dubberly
- Øyvind de Freitas Sørensen
- Kori Roys
- Michael Lang
- Ian Maclean
- Sergey Cheperis
- Asem Hasna
- gb
