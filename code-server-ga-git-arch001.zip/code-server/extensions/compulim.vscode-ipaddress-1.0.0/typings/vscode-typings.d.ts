/// <reference path="../node_modules/vscode/typings/index-js.d.ts" />
